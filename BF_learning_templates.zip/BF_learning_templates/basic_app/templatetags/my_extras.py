from django import template
register=template.Library

@register.filter(name='cut')
def cut(value,arg):
    """
    This cuts out all values of arg from the input value string
    """
    return value.replace(arg, '')

# register.filter('cut',cut)  #First argument is the name to be called from the template tag in the html, the second is the actual function
