import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE",'ModelFormPro2.settings')

import django
django.setup()

from ModelFormApp2.models import SiteUser

from faker import Faker
fakergen=Faker()

def fillusers(N):

    for entry in range(N):
        fakefullname=fakergen.name().split()
        fakefirstname=fakefullname[0]
        fakelastname=fakefullname[1]
        fakeemail=fakergen.email()

        newuser=SiteUser.objects.get_or_create(firstname=fakefirstname, lastname=fakelastname, email=fakeemail)

if __name__=='__main__':
    print('STARTED')
    fillusers(50)
    print('ENDED')
