from django.apps import AppConfig


class Modelformapp2Config(AppConfig):
    name = 'ModelFormApp2'
