from django.contrib import admin
from ModelFormApp2.models import SiteUser

# Register your models here.

admin.site.register(SiteUser)
