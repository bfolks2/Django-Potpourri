from django.conf.urls import url
from ModelFormApp2 import views

urlpatterns=[
    url(r'^$',views.siteuser, name='userurl'),
]
