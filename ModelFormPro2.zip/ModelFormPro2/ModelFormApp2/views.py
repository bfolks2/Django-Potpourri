from django.shortcuts import render
from ModelFormApp2.forms import SiteUserForm

# Create your views here.

def index(request):
    return render(request, 'ModelFormApp2/index.html')

def siteuser(request):
    form=SiteUserForm()

    if request.method=='POST':
        form=SiteUserForm(request.POST)

        if form.is_valid():
            form.save(commit=True)
            return index(request)
        else:
            print('ERROR SAVING DATA')

    return render(request, 'ModelFormApp2/user_reg.html', {'formkey':form})



    # user_list=SiteUser.objects.order_by('firstname')
    # user_dict={'userkey':user_list}
    # return render(request, 'ModelFormApp2/user_reg.html',user_dict)
