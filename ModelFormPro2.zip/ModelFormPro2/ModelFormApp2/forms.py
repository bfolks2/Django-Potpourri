from django import forms
from ModelFormApp2.models import SiteUser

class SiteUserForm(forms.ModelForm):
    class Meta():
        model=SiteUser
        fields='__all__'
