from django.conf.urls import url
from BFSoloFormApp import views

urlpatterns=[
    url(r'^$',views.formview,name='formurl')
]
