from django.apps import AppConfig


class BfsoloformappConfig(AppConfig):
    name = 'BFSoloFormApp'
