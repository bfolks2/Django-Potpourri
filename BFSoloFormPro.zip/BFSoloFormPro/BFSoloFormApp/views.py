from django.shortcuts import render
from BFSoloFormApp import forms

# Create your views here.

def index(request):
    return render(request, 'BFSoloFormApp/index.html')

def formview(request):
    form = forms.InputForm()
    form_dict={'formkey':form}


    if request.method=='POST':
        form=forms.InputForm(request.POST)

        if form.is_valid():
            print('SUCCESS')
            print('NAME: ' +form.cleaned_data['namey'])
            print('EMAIL: '+form.cleaned_data['email'])
            print('TEXT: '+form.cleaned_data['text'])


    return render(request, 'BFSoloFormApp/formpage.html',context=form_dict)
