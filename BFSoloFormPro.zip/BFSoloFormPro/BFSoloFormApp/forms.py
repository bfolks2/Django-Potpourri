from django import forms
from django.core import validators

#Check that name attribute value starts with "z"
# def check_for_z(value):
#     if value[0].lower() != 'z':
#         raise forms.ValidationError('Name must start with Z')


class InputForm(forms.Form):
    # name=forms.CharField(validators=[check_for_z])
    namey=forms.CharField()
    email=forms.EmailField()
    verifyemail=forms.EmailField(label='Enter Your Email Again')
    text=forms.CharField(widget=forms.Textarea)

    #Cleans all form data
    def clean(self):
        all_clean_data=super().clean()
        email=all_clean_data['email']
        verifyemail = all_clean_data['verifyemail']

        if email != verifyemail:
            raise forms.ValidationError('Emails do not match')

    # botcatcher=forms.CharField(required=False, widget=forms.HiddenInput, validators=[validators.MaxLengthValidator(0)])

    # def clean_botcatcher(self):
    #     botcatcher=self.cleaned_data['botcatcher']
    #     if len(botcatcher)>0:
    #         raise forms.ValidationError('GOTCHA BOT, YOU BITCH!')
    #     return botcatcher
